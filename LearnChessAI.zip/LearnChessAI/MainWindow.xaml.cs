﻿using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static LearnChessAI.MainWindow;

namespace LearnChessAI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 


    public partial class MainWindow : Window
    {
        public bool GameOver { get; set; } = false;
        private Button selectedSquare;
        private ChessBoard board;
        private HardBot hardBot;
        private EasyBot easyBot;
        public string currentPlayer = "White"; //sets the current player to be the User, the User will always be first to start the game.
        private bool isEasyMode = true;
        public MainWindow()
        {
            InitializeComponent();


            board = new ChessBoard();  
            chessboard = (Grid)FindName("chessboard");
            hardBot = null;
            easyBot = null;
            if (chessboard != null)
            {
                InitialiseChessBoard_UI();
            }
            else
            {
                MessageBox.Show("Error: Chessboard is not initialized."); //helps with error handling
            }
            UpdateUI();

        }
        public string CurrentPlayer
        {
            get { return currentPlayer; }
            set { currentPlayer = value; }
        }
        public void InitialiseChessBoard_UI()
        {
            // Clear existing children (in case of reset)
            chessboard.Children.Clear();

            // Loop through each square of the chessboard
            for (int row = 0; row < 8; row++)
            {
                for (int col = 0; col < 8; col++)
                {
                    // Create a button for the square
                    Button square = new Button
                    {
                        Width = 70,
                        Height = 70,
                        // Alternate colors for the board
                        Background = (row + col) % 2 == 0 ? Brushes.Beige : Brushes.SaddleBrown,
                        Tag = new Tuple<int, int>(row, col)
                    };

                    // Attach the click event handler
                    square.Click += Square_Click;

                    // If there's a piece at [row, col], set the button's Content to an Image
                    Piece piece = board.Board[row, col];
                    if (piece != null)
                    {
                        Image pieceImage = new Image
                        {
                            Width = 70,
                            Height = 70,
                            VerticalAlignment = VerticalAlignment.Center,
                            HorizontalAlignment = HorizontalAlignment.Center
                        };

                        try
                        {
                            pieceImage.Source = new BitmapImage(new Uri(
                                $"pack://application:,,,/Images/{piece.TypeOfPiece()}_{piece.Color}.png",
                                UriKind.Absolute));
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Error loading image: {ex.Message}"); //error checking
                        }

                        square.Content = pieceImage;
                    }

                    // Place the button in the chessboard grid
                    Grid.SetRow(square, row);
                    Grid.SetColumn(square, col);
                    chessboard.Children.Add(square);
                }
            }
        }
        private void DifficultySelector_SelectionChanged(object sender, SelectionChangedEventArgs e) //on-screen button
        {
            if (DifficultySelector.SelectedItem is ComboBoxItem selectedItem)
            {
                string selectedDifficulty = selectedItem.Content.ToString();

                if (selectedDifficulty == "EasyBot")
                {
                    // Create an EasyBot if it doesn't exist yet
                    if (easyBot == null)
                    {
                        easyBot = new EasyBot(this,board);
                    }

                    // Indicate we are in Easy mode
                    isEasyMode = true;
                    MessageBox.Show("EasyBot selected!");
                }
                else if (selectedDifficulty == "HardBot")
                {
                    // Create a HardBot if it doesn't exist yet
                    if (hardBot == null)
                    {
                        hardBot = new HardBot(this);
                    }

                    // Indicate we are in Hard mode
                    isEasyMode = false;
                    MessageBox.Show("HardBot selected!");
                }
            }
        }

        private void Square_Click(object sender, RoutedEventArgs e)
        {
            if (chessboard == null) return;

            Button clickedSquare = sender as Button;
            if (clickedSquare == null) return;

            int clickedRow = Grid.GetRow(clickedSquare);
            int clickedCol = Grid.GetColumn(clickedSquare);

            if (selectedSquare == null)
            {
                // First click: select a piece
                Piece selectedPiece = board.GetPiece(clickedRow, clickedCol);

                if (selectedPiece == null || selectedPiece.Color != currentPlayer)
                {
                    MessageBox.Show("Invalid selection! Please select a valid piece.");
                    return;
                }

                // Highlight the selected square
                clickedSquare.Background = Brushes.LightBlue;
                selectedSquare = clickedSquare;
            }
            else
            {
                // Second click: attempt to move the selected piece
                int startRow = Grid.GetRow(selectedSquare);
                int startCol = Grid.GetColumn(selectedSquare);

                bool moveSuccessful = HandleMove(startRow, startCol, clickedRow, clickedCol);

                if (moveSuccessful)
                {
                    moveCount++;

                    // Check for game end after human move
                    CheckForGameEnd(board.Board);

                    //Display a hint every 3 moves
                    if (moveCount % 3 == 0)
                    {
                        HardBot bot = new HardBot(this);
                        string hint = bot.GetHint(board.Board);
                        HintLabel.Text = "Hint: " + hint;
                    }

                    UpdateUI();  // Refresh after human move
                    if (currentPlayer == "Black")
                    {
                        if (isEasyMode && easyBot != null)
                        {
                            easyBot.MakeMove();
                        }
                        else if (!isEasyMode && hardBot != null) //makes sure Bot is not null, to ensure MakeAIMove would work
                        {
                            hardBot.MakeAIMove(board.Board);
                        }

                        moveCount++;

                        UpdateUI();  // Refresh after AI move

                        // Check for game end after bot move
                        CheckForGameEnd(board.Board);
                    }
                }
                else
                {
                    MessageBox.Show("Illegal move! Try again.");
                }
                // Reset the color of the previously selected square
                int startRowColor = Grid.GetRow(selectedSquare);
                int startColColor = Grid.GetColumn(selectedSquare);
                selectedSquare.Background = (startRowColor + startColColor) % 2 == 0 ? Brushes.Beige : Brushes.SaddleBrown;

                selectedSquare = null;
            }
        }
        private void CheckForGameEnd(Piece[,] board)
        {
            if (IsCheckmate(board, "White"))
            {
                if (MessageBox.Show("Checkmate! Black wins. Do you want to play again?", "Game Over", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    RestartGame(); 
                }
                else
                {
                    Application.Current.Shutdown();  // Exit gracefully
                }
            }
            else if (IsCheckmate(board, "Black"))
            {
                if (MessageBox.Show("Checkmate! White wins. Do you want to play again?", "Game Over", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    RestartGame();
                }
                else
                {
                    Application.Current.Shutdown();
                }
            }
            else if (IsStalemate(board,CurrentPlayer))
            {
                if (MessageBox.Show("Stalemate! It's a draw. Do you want to play again?", "Game Over", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    RestartGame(); 
                }
                else
                {
                    Application.Current.Shutdown();
                }
            }
        }
        public bool IsStalemate(Piece[,] board, string color)
        {
            // If the king is in check, it's not stalemate
            if (hardBot.IsKingInCheck(board, color))
                return false;

            // Get all legal moves
            var legalMoves = hardBot.GetAllLegalMoves(board, color);

            // If no legal moves exist, it's stalemate
            return legalMoves.Count == 0;
        }
        private bool IsKingInCheck(Piece[,] board, (int, int, int, int) move)
        {
            Piece[,] testBoard = hardBot.SimulateMove(board, move.Item1, move.Item2, move.Item3, move.Item4);

            // Find the king's position
            int kingRow = -1, kingCol = -1;
            for (int row = 0; row < 8; row++)
            {
                for (int col = 0; col < 8; col++)
                {
                    if (testBoard[row, col] is King && testBoard[row, col].Color == "White") // Checking opponent's king
                    {
                        kingRow = row;
                        kingCol = col;
                        break;
                    }
                }
            }

            // Check if any piece can attack the king
            for (int row = 0; row < 8; row++)
            {
                for (int col = 0; col < 8; col++)
                {
                    Piece piece = testBoard[row, col];
                    if (piece != null && piece.Color == "Black") // AI's pieces
                    {
                        if (piece.IsMoveLegal(row, col, kingRow, kingCol, testBoard))
                        {
                            return true; // King is under attack
                        }
                    }
                }
            }

            return false;
        }
        public bool IsCheckmate(Piece[,] board, string color)
        {
            // Check if the king is in check
            if (!hardBot.IsKingInCheck(board, color))
                return false;

            // Get all legal moves
            var legalMoves = hardBot.GetAllLegalMoves(board, color);

            // If no legal moves exist, it's checkmate
            return legalMoves.Count == 0;
        }
        private void ShowGameOverPrompt(string message) //On-Screen message when Game has finished.
        {
            MessageBoxResult result = MessageBox.Show(
                $"{message}\nDo you want to restart the game?",
                "Game Over",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question
            );

            if (result == MessageBoxResult.Yes)
            {
                RestartGame();
            }
            else
            {
                Application.Current.Shutdown();
            }
        }
        public void RestartGame()
        {
            board = new ChessBoard();  // Created a new board instance to fully reset game
            CurrentPlayer = "White";
            moveCount = 0;              // Reset move count
            chessboard.Children.Clear();
            InitialiseChessBoard_UI();
            UpdateUI();
        }
        public bool HandleMove(int startRow, int startCol, int endRow, int endCol)
        {
            Piece piece = board.Board[startRow, startCol];

            if (piece == null || piece.Color != currentPlayer)
            {
                MessageBox.Show("Invalid piece selected!"); //Can not choose a piece that is not the player's colour
                return false;
            }

            if (board.IsMoveLegal(startRow, startCol, endRow, endCol)) //Makes sure the move played is one that is legal
            {
                board.MovePiece(startRow, startCol, endRow, endCol);

                // Check for pawn promotion
                if (piece is Pawn && (endRow == 0 || endRow == 7))
                {
                    board.Board[endRow, endCol] = new Queen(piece.Color);
                }

                // Check for checkmate
                if (IsCheckmate(board.Board, currentPlayer))
                {
                    ShowGameOverPrompt(currentPlayer + " wins by Checkmate!"); 
                    return true;
                }

                // Switch turns
                currentPlayer = currentPlayer == "White" ? "Black" : "White";
                return true;
            }
            else
            {
                MessageBox.Show("That move is illegal.");
                return false;
            }
        }
        // Retrieve a square without passing Chessboard as a parameter
        private Button GetSquare(int row, int col)
        {
            if (chessboard == null) return null; // Ensure Chessboard is initialized

            foreach (UIElement element in chessboard.Children)
            {
                if (element is Button button)
                {
                    if (Grid.GetRow(button) == row && Grid.GetColumn(button) == col)
                    {
                        return button;
                    }
                }
            }
            return null;
        }

        // Update UI makes it so the images of pieces are in the correct place each turn
        public void UpdateUI()
        {
            if (chessboard == null) return;

            for (int row = 0; row < 8; row++)
            {
                for (int col = 0; col < 8; col++)
                {
                    Button square = GetSquare(row, col);
                    if (square == null) continue;

                    Piece piece = board.GetPiece(row, col);

                    if (piece != null)
                    {
                        string imagePath = $"pack://application:,,,/Images/{piece.TypeOfPiece()}_{piece.Color}.png";

                        square.Content = new Image
                        {
                            Source = new BitmapImage(new Uri(imagePath, UriKind.Absolute)),
                            Stretch = Stretch.Uniform
                        };
                    }
                    else
                    {
                        square.Content = null;
                    }
                }
            }
        }

        public int moveCount = 0;
        private void OnMoveMade(Piece[,] board) //after a move is made
        {
            moveCount++;
            //
            CheckForGameEnd(board);
            HardBot bot = new HardBot(this);
            string hint = bot.GetHint(board);
            HintLabel.Text = "Hint: " + hint;
        }
        public class ChessBoard //Object Orientated Programming of the Board and its Pieces.
        {
            public Piece[,] Board { get; private set; }
            public ChessBoard()
            {
                Board = new Piece[8, 8];
                InitialiseBoard();
            }

            public void InitialiseBoard()
            {
                // Clear the entire board first
                for (int row = 0; row < 8; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        Board[row, col] = null;
                    }
                }
                for (int i = 0; i < 8; i++)
                {
                    Board[1, i] = new Pawn("Black");
                    Board[6, i] = new Pawn("White");
                }

                Board[0, 0] = new Rook("Black");
                Board[0, 7] = new Rook("Black");
                Board[7, 0] = new Rook("White");
                Board[7, 7] = new Rook("White");


                Board[0, 1] = new Knight("Black");
                Board[0, 6] = new Knight("Black");
                Board[7, 1] = new Knight("White");
                Board[7, 6] = new Knight("White");


                Board[0, 2] = new Bishop("Black");
                Board[0, 5] = new Bishop("Black");
                Board[7, 2] = new Bishop("White");
                Board[7, 5] = new Bishop("White");


                Board[0, 4] = new King("Black");
                Board[7, 4] = new King("White");


                Board[0, 3] = new Queen("Black");
                Board[7, 3] = new Queen("White");
            }
            public Piece GetPiece(int row, int col)
            {
                return Board[row, col]; //returns which piece is in the square of the board that has been passed as a parameter.
            }
            public bool IsMoveLegal(int startRow, int startCol, int endRow, int endCol)
            {
                Piece piece = Board[startRow, startCol];
                if (piece == null) return false; // No piece to move

                return piece.IsMoveLegal(startRow, startCol, endRow, endCol, Board);
            }

            public void MovePiece(int startRow, int startCol, int endRow, int endCol)
            {
                Piece movedPiece = Board[startRow, startCol];
                Board[endRow, endCol] = movedPiece;
                Board[startRow, startCol] = null;

                // Handle pawn promotion
                if (movedPiece is Pawn && (endRow == 0 || endRow == 7))
                {
                    Board[endRow, endCol] = new Queen(movedPiece.Color);
                }
            }
            // Finds if the current player's king is in check


        }
        public abstract class Piece //parent class for the pieces that are being used within the chessboard
        {
            public string Color { get; } // "White" for White, "Black" for Black
            protected Piece(string color)
            {
                Color = color;
            }

            public abstract bool IsMoveLegal(int startRow, int startCol, int endRow, int endCol, Piece[,] board); //overriden by each subclass, as each piece has a different moveset
            public abstract string TypeOfPiece();
            public virtual Piece Clone()
            {
                return (Piece)MemberwiseClone();
            }

        }
        public class Pawn : Piece //child of the parent class "peice"
        {
            public Pawn(string colour) : base(colour)
            {

            }
            public override Piece Clone()
            {
                return new Pawn(this.Color); 
            }
            public override string TypeOfPiece()
            {
                return "Pawn"; //string of the type of piece, used in spawning the png
            }

            public override bool IsMoveLegal(int startRow, int startCol, int endRow, int endCol, Piece[,] board)
            {
                int direction = Color == "White" ? -1 : 1; // White moves up, Black moves down
                int startRank = Color == "White" ? 6 : 1; // Starting rank

                // Forward movement (only allowed if the destination square is empty)
                if (endCol == startCol && board[endRow, endCol] == null)
                {
                    if (endRow == startRow + direction) return true; // Move one square forward
                    if (startRow == startRank && endRow == startRow + 2 * direction && board[startRow + direction, startCol] == null)
                        return true; // Move two squares forward from starting position
                }

                // Capturing (only allowed diagonally if there's an opponent's piece)
                if (Math.Abs(endCol - startCol) == 1 && endRow == startRow + direction)
                {
                    // Ensure there is a piece of the opposite color when moving diagonally
                    if (board[endRow, endCol] != null && board[endRow, endCol].Color != Color)
                    {
                        return true; // Diagonal capture
                    }
                }

                return false; // Invalid move
            }
            private void PromoteIfApplicable(int row, int col, Piece[,] board)
            {
                int promotionRow = Color == "White" ? 0 : 7; // Promotion row (8th for white, 1st for black)

                if (row == promotionRow)
                {
                    board[row, col] = new Queen(Color); // Replace the pawn with a queen
                }
            }
        }
        public class King : Piece
        {
            public bool HasMoved { get; set; } = false;  // To track castling eligibility

            public King(string color) : base(color) { }

            public override Piece Clone()
            {
                return new King(this.Color) { HasMoved = this.HasMoved };
            }

            public override string TypeOfPiece()
            {
                return "King";
            }


            public override bool IsMoveLegal(int startRow, int startCol, int endRow, int endCol, Piece[,] board)
            {
                // Call the overloaded method with null HardBot reference
                return IsMoveLegal(startRow, startCol, endRow, endCol, board, null);
            }

            // Overloaded version with null-check for bot, so that Board does not have to be passed through IsMoveLegal
            public bool IsMoveLegal(int startRow, int startCol, int endRow, int endCol, Piece[,] board, HardBot bot)
            {
                int rowDiff = Math.Abs(startRow - endRow);
                int colDiff = Math.Abs(startCol - endCol);

                // Normal King Move (one square in any direction)
                if (rowDiff <= 1 && colDiff <= 1)
                {
                    Piece destinationPiece = board[endRow, endCol];
                    if (destinationPiece == null || destinationPiece.Color != this.Color)
                    {
                        return true;
                    }
                }

                // Castling Logic
                if (!HasMoved && rowDiff == 0 && colDiff == 2)
                {
                    int direction = (endCol > startCol) ? 1 : -1;
                    int rookCol = (endCol > startCol) ? 7 : 0;
                    Piece rook = board[startRow, rookCol];

                    if (rook is Rook && !((Rook)rook).HasMoved)
                    {
                        // Check for clear path
                        for (int col = startCol + direction; col != rookCol; col += direction)
                        {
                            if (board[startRow, col] != null)
                                return false;
                        }

                        // Ensure King doesn't move through check
                        if (bot != null)  //  Null check to avoid the exception
                        {
                            Piece[,] boardAfterMove = bot.SimulateMove(board, startRow, startCol, endRow, endCol);

                            if (!bot.IsKingInCheck(board, this.Color) && !bot.IsKingInCheck(boardAfterMove, this.Color))
                            {
                                return true;
                            }
                        }
                        else
                        {
                            // If bot is null, allow castling without checking for check
                            return true;
                        }
                    }
                }

                return false;
            }
        }
        public class Rook : Piece
        {
            public bool HasMoved { get; set; } = false;  // Castling eligibility

            public Rook(string color) : base(color) { }

            public override Piece Clone()
            {
                return new Rook(this.Color) { HasMoved = this.HasMoved };
            }

            public override string TypeOfPiece()
            {
                return "Rook";
            }

            public override bool IsMoveLegal(int startRow, int startCol, int endRow, int endCol, Piece[,] board)
            {
                int boardSize = board.GetLength(0);  // Ensure within board boundaries

                // Prevent out of bounds access
                if (endRow < 0 || endRow >= boardSize || endCol < 0 || endCol >= boardSize)
                {
                    return false;  // Invalid move (out of bounds)
                }

                Piece targetPiece = board[endRow, endCol];

                if (targetPiece == null || targetPiece.Color != this.Color)
                {
                    if (startRow == endRow || startCol == endCol)  // Horizontal or vertical move
                    {
                        if (IsPathClear(startRow, startCol, endRow, endCol, board))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }

            private bool IsPathClear(int startRow, int startCol, int endRow, int endCol, Piece[,] board)
            {
                int boardSize = board.GetLength(0);  // Ensure within board boundaries

                if (startRow == endRow)  // Horizontal move
                {
                    int step = (endCol > startCol) ? 1 : -1;
                    for (int col = startCol + step; col != endCol; col += step)
                    {
                        if (col < 0 || col >= boardSize)  // Out of bounds check
                            return false;

                        if (board[startRow, col] != null)
                            return false;  // Path is blocked
                    }
                }
                else if (startCol == endCol)  // Vertical move
                {
                    int step = (endRow > startRow) ? 1 : -1;
                    for (int row = startRow + step; row != endRow; row += step)
                    {
                        if (row < 0 || row >= boardSize)  // Out of bounds check
                            return false;

                        if (board[row, startCol] != null)
                            return false;  // Path is blocked
                    }
                }

                return true;
            }
        }
        public class Bishop : Piece
        {
            public Bishop(string color) : base(color) { }
            public override string TypeOfPiece()
            {
                return "Bishop";
            }

            public override bool IsMoveLegal(int startRow, int startCol, int endRow, int endCol, Piece[,] board)
            {
                int boardSize = board.GetLength(0);

                // Bounds check to prevent out of bounds access
                if (startRow < 0 || startRow >= boardSize || startCol < 0 || startCol >= boardSize ||
                    endRow < 0 || endRow >= boardSize || endCol < 0 || endCol >= boardSize)
                {
                    return false;  // Move is out of bounds
                }

                // Bishops move diagonally, so row and col difference must be equal
                int rowDiff = Math.Abs(endRow - startRow);
                int colDiff = Math.Abs(endCol - startCol);

                if (rowDiff != colDiff)
                    return false;

                // Determine the direction of movement
                int rowStep = (endRow > startRow) ? 1 : -1;
                int colStep = (endCol > startCol) ? 1 : -1;

                int row = startRow + rowStep;
                int col = startCol + colStep;

                // Check the path for obstructions
                while (row != endRow && col != endCol)
                {
                    if (row < 0 || row >= boardSize || col < 0 || col >= boardSize)
                    {
                        return false;  // Double bounds check during traversal
                    }

                    if (board[row, col] != null)
                    {
                        return false;  // Path is blocked
                    }

                    row += rowStep;
                    col += colStep;
                }

                // Check the destination square
                Piece targetPiece = board[endRow, endCol];

                if (targetPiece == null || targetPiece.Color != this.Color)
                {
                    return true;  // Either the square is empty or holds an opponent's piece
                }

                return false;
            }
        }
        public class Queen : Piece // The Queen combines the Rook and Bishop movements
        {
            public Queen(string color) : base(color) { }

            public override Piece Clone()
            {
                return new Queen(this.Color);
            }

            public override string TypeOfPiece()
            {
                return "Queen";
            }

            public override bool IsMoveLegal(int startRow, int startCol, int endRow, int endCol, Piece[,] board)
            {
                int boardSize = board.GetLength(0);

                // Bounds check to prevent out of bounds access
                if (startRow < 0 || startRow >= boardSize || startCol < 0 || startCol >= boardSize ||
                    endRow < 0 || endRow >= boardSize || endCol < 0 || endCol >= boardSize)
                {
                    return false;  // Move is out of bounds
                }
                Piece destinationPiece = board[endRow, endCol];

                // Return true if the destination is empty or has an opponent's piece
                if (destinationPiece == null || destinationPiece.Color != this.Color)
                {
                    // Rook-like movement (horizontal/vertical)
                    if (startRow == endRow || startCol == endCol)
                    {
                        return IsPathClearRook(startRow, startCol, endRow, endCol, board);
                    }
                    // Bishop-like movement (diagonal)
                    if (Math.Abs(startRow - endRow) == Math.Abs(startCol - endCol))
                    {
                        return IsPathClearBishop(startRow, startCol, endRow, endCol, board);
                    }
                }
                return false;  // Invalid move if it doesn't fit either pattern
            }

            private bool IsPathClearRook(int startRow, int startCol, int endRow, int endCol, Piece[,] board)
            {
                int boardSize = board.GetLength(0);

                if (startRow == endRow) // Horizontal movement
                {
                    int step = (endCol > startCol) ? 1 : -1;
                    for (int col = startCol + step; col != endCol; col += step)
                    {
                        if (col < 0 || col >= boardSize) return false;  // Bounds check
                        if (board[startRow, col] != null) return false;  // Path blocked
                    }
                }
                else if (startCol == endCol) // Vertical movement
                {
                    int step = (endRow > startRow) ? 1 : -1;
                    for (int row = startRow + step; row != endRow; row += step)
                    {
                        if (row < 0 || row >= boardSize) return false;  // Bounds check
                        if (board[row, startCol] != null) return false;  // Path blocked
                    }
                }

                return true;  // Path is clear
            }

            private bool IsPathClearBishop(int startRow, int startCol, int endRow, int endCol, Piece[,] board)
            {
                int boardSize = board.GetLength(0);

                int rowStep = (endRow > startRow) ? 1 : -1;
                int colStep = (endCol > startCol) ? 1 : -1;

                int currentRow = startRow + rowStep;
                int currentCol = startCol + colStep;

                while (currentRow != endRow && currentCol != endCol)
                {
                    if (currentRow < 0 || currentRow >= boardSize || currentCol < 0 || currentCol >= boardSize)
                    {
                        return false;  // Bounds check
                    }

                    if (board[currentRow, currentCol] != null)
                    {
                        return false;  // Path is blocked
                    }

                    currentRow += rowStep;
                    currentCol += colStep;
                }

                return true;  // Path is clear
            }
        }
        public class Knight : Piece // The knight moves in an "L" shape: (2,1) or (1,2) are the modulus of the possible vectors
        {
            public Knight(string color) : base(color) { }

            public override Piece Clone()
            {
                return new Knight(this.Color);
            }

            public override string TypeOfPiece()
            {
                return "Knight";
            }

            public override bool IsMoveLegal(int startRow, int startCol, int endRow, int endCol, Piece[,] board)
            {
                int boardSize = board.GetLength(0);

                // Bounds check to prevent out of bounds access
                if (startRow < 0 || startRow >= boardSize || startCol < 0 || startCol >= boardSize ||
                    endRow < 0 || endRow >= boardSize || endCol < 0 || endCol >= boardSize)
                {
                    return false;  // Move is out of bounds
                }

                int rowDifference = Math.Abs(startRow - endRow);
                int colDifference = Math.Abs(startCol - endCol);

                // Check for L-shaped movement
                bool isLShapedMove = (rowDifference == 2 && colDifference == 1) ||
                                     (rowDifference == 1 && colDifference == 2);

                if (isLShapedMove)
                {
                    // Check if destination is empty or contains an opponent's piece
                    Piece destinationPiece = board[endRow, endCol];

                    // Return true if the destination is empty or has an opponent's piece
                    if (destinationPiece == null || destinationPiece.Color != this.Color)
                    {
                        return true;
                    }
                }

                return false;  // Invalid move
            }
        }

        public class EasyBot
        {
            private ChessBoard board;
            private Random random;
            private MainWindow mainwindow;

            public EasyBot(MainWindow mainwindow, ChessBoard board)
            {
                random = new Random();
                this.mainwindow = mainwindow;

                if (board == null || board.Board == null)
                {
                    Console.WriteLine("Error: Board is null in EasyBot constructor.");
                    throw new ArgumentNullException(nameof(board), "Board cannot be null.");
                }

                this.board = board;
            }

            public void MakeMove()
            {
                if (board == null || board.Board == null)
                {
                    Console.WriteLine("Error: Board is null during MakeMove().");
                    return;
                }

                // Get all legal moves
                List<(int startRow, int startCol, int endRow, int endCol)> legalMoves = GetLegalMovesAvoidingCheck();

                if (legalMoves.Count == 0)
                {
                    // No legal moves = check for stalemate or checkmate
                    mainwindow.CheckForGameEnd(board.Board);  
                    return;
                }

                //Pick a random legal move
                var (startRow, startCol, endRow, endCol) = legalMoves[random.Next(legalMoves.Count)];

                // Execute the move
                Piece piece = board.Board[startRow, startCol];
                if (piece == null)
                {
                    Console.WriteLine("Error: Tried to move a null piece.");
                    return;
                }

                board.Board[endRow, endCol] = piece;      // Move the piece
                board.Board[startRow, startCol] = null;   // Remove it from the original location

                // Update the UI
                mainwindow.OnMoveMade(board.Board);

                Console.WriteLine($"Easy Bot moved {piece.TypeOfPiece()} from ({startRow}, {startCol}) to ({endRow}, {endCol})");

                // Check for stalemate or checkmate after the move
                mainwindow.CheckForGameEnd(board.Board);

                // Switch back to the user's turn
                mainwindow.CurrentPlayer = "White";
            }

            // Get all legal moves that don't leave the king in check.
            private List<(int, int, int, int)> GetLegalMovesAvoidingCheck()
            {
                List<(int, int, int, int)> legalMoves = BotUtils.GetAllLegalMoves(board.Board, "Black");

                List<(int, int, int, int)> safeMoves = new();

                foreach (var move in legalMoves)
                {
                    if (!IsKingInCheck(board.Board, move))
                    {
                        safeMoves.Add(move);
                    }
                }

                return safeMoves;
            }

            // Check if the specified king is in check.
            private bool IsKingInCheck(Piece[,] board, (int, int, int, int) move)
            {
                Piece[,] testBoard = SimulateMove(board, move.Item1, move.Item2, move.Item3, move.Item4);

                // Find the black king's position
                int kingRow = -1, kingCol = -1;

                for (int row = 0; row < 8; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        if (testBoard[row, col] is King king && king.Color == "Black")
                        {
                            kingRow = row;
                            kingCol = col;
                            break;
                        }
                    }
                }

                // Check if any white piece can attack the black king
                for (int row = 0; row < 8; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        Piece piece = testBoard[row, col];
                        if (piece != null && piece.Color == "White")
                        {
                            if (piece.IsMoveLegal(row, col, kingRow, kingCol, testBoard))
                            {
                                return true;  // Black king is under attack
                            }
                        }
                    }
                }

                return false;  // King is safe
            }
            // Simulate a move on a temporary board to check if it results in check.
            private Piece[,] SimulateMove(Piece[,] board, int startRow, int startCol, int endRow, int endCol)
            {
                Piece[,] newBoard = new Piece[8, 8];

                // Copy the board state
                for (int row = 0; row < 8; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        newBoard[row, col] = board[row, col] != null ? board[row, col].Clone() : null;
                    }
                }

                Piece movingPiece = newBoard[startRow, startCol];

                if (movingPiece is King king && Math.Abs(startCol - endCol) == 2)
                {
                    //  Castling logic
                    int rookCol = (endCol > startCol) ? 7 : 0;
                    int newRookCol = (endCol > startCol) ? endCol - 1 : endCol + 1;

                    // Move the King
                    newBoard[endRow, endCol] = movingPiece;
                    newBoard[startRow, startCol] = null;

                    // Move the Rook
                    newBoard[endRow, newRookCol] = newBoard[endRow, rookCol];
                    newBoard[endRow, rookCol] = null;
                }
                else
                {
                    // Standard move
                    newBoard[endRow, endCol] = newBoard[startRow, startCol];
                    newBoard[startRow, startCol] = null;
                }

                return newBoard;
            }
        }
        public class HardBot
        {
            public ChessBoard board;
            private MainWindow mainWindow;  // Store reference to MainWindow

            public HardBot(MainWindow mainWindow)
            {
                this.mainWindow = mainWindow;
            }
            public string GetHint(Piece[,] board)
            {
                var legalMoves = GetAllLegalMoves(board, "White");  // Generate moves for the current player

                if (legalMoves.Count == 0)
                {
                    return "No valid moves available.";
                }

                // Check for threats
                var threatHint = GetThreatHint(board);
                if (!string.IsNullOrEmpty(threatHint))
                {
                    return threatHint;
                }

                // Check for winning moves
                // Convert List into Tuple format
                var tupleMoves = legalMoves
                    .Select(move => new Tuple<int, int, int, int>(move.Item1, move.Item2, move.Item3, move.Item4))
                    .ToList();

                // Pass the converted list to the method
                var winningMove = GetWinningMoveHint(board, tupleMoves);
                if (!string.IsNullOrEmpty(winningMove))
                {
                    return winningMove;
                }

                // Check for positional improvements
                var positionalHint = GetPositionalHint(board);
                if (!string.IsNullOrEmpty(positionalHint))
                {
                    return positionalHint;
                }

                var random = new Random();
                var randomMove = legalMoves[random.Next(legalMoves.Count)];
                var convertedMove = new Tuple<int, int, int, int>(randomMove.Item1, randomMove.Item2, randomMove.Item3, randomMove.Item4); //converted to tuple
                string moveDescription = GetMoveDescription(board, convertedMove);
                return $"Try moving your {moveDescription}."; //Text for Hint
            }
            private string GetMoveDescription(Piece[,] board, Tuple<int, int, int, int> move)
            {
                var piece = board[move.Item1, move.Item2];
                string pieceName = piece != null ? piece.TypeOfPiece() : "Unknown";
                return $"{pieceName} from ({move.Item1}, {move.Item2}) to ({move.Item3}, {move.Item4})";
            }
            private string GetPositionalHint(Piece[,] board)
            {
                // Suggest centralisation
                var centerSquares = new List<Tuple<int, int>> { Tuple.Create(3, 3), Tuple.Create(3, 4), Tuple.Create(4, 3), Tuple.Create(4, 4) };

                foreach (var square in centerSquares)
                {
                    var piece = board[square.Item1, square.Item2];
                    if (piece != null && piece.Color == "White")
                    {
                        return $"🔥 Centralize your {piece.TypeOfPiece()} for better control.";
                    }
                }

                return string.Empty;
            }
            private string GetWinningMoveHint(Piece[,] board, List<Tuple<int, int, int, int>> legalMoves)
            {
                foreach (var move in legalMoves)
                {
                    Piece[,] simulatedBoard = SimulateMove(board, move.Item1, move.Item2, move.Item3, move.Item4);

                    // Checkmate detection
                    if (mainWindow.IsCheckmate(simulatedBoard, "Black"))
                    {
                        return $"🔥 You have checkmate in one move! Move your {board[move.Item1, move.Item2].TypeOfPiece()} to ({move.Item3}, {move.Item4}).";
                    }

                    // check the board, not the simulated one
                    if (board[move.Item3, move.Item4] != null)
                    {
                        var capturedPiece = board[move.Item3, move.Item4];
                        return $"🎯 You can capture the {capturedPiece.TypeOfPiece()} at ({move.Item3}, {move.Item4}).";
                    }
                }

                return string.Empty;
            }
            private string GetThreatHint(Piece[,] board)
            {
                var opponentMoves = GetAllLegalMoves(board, "Black");

                foreach (var move in opponentMoves)
                {
                    int endRow = move.Item3;
                    int endCol = move.Item4;

                    Piece threatenedPiece = board[endRow, endCol];

                    if (threatenedPiece != null && threatenedPiece.Color == "White")
                    {
                        return $"⚠️ Your {threatenedPiece.TypeOfPiece()} is under attack! Consider defending or moving it."; //emojis to help atmoshphere
                    }
                }

                return string.Empty;
            }
            private int EvaluateBoard(Piece[,] board)
            {
                int evaluation = 0;


                Dictionary<string, int> pieceValues = new()
    {
        { "Pawn", 100 }, { "Knight", 320 }, { "Bishop", 330 },
        { "Rook", 500 }, { "Queen", 900 }, { "King", 20000 }
    };

                // Piece-Square Tables
                int[,] pawnTable = {
        {  0,  0,  0,  0,  0,  0,  0,  0 },
        { 50, 50, 50, 50, 50, 50, 50, 50 },
        { 10, 10, 20, 30, 30, 20, 10, 10 },
        {  5,  5, 10, 25, 25, 10,  5,  5 },
        {  0,  0,  0, 20, 20,  0,  0,  0 },
        {  5, -5, -10,  0,  0, -10, -5,  5 },
        {  5, 10, 10, -20, -20, 10, 10,  5 },
        {  0,  0,  0,  0,  0,  0,  0,  0 }
    };

                int[,] knightTable = {
        { -50, -40, -30, -30, -30, -30, -40, -50 },
        { -40, -20,   0,   5,   5,   0, -20, -40 },
        { -30,   5,  10,  15,  15,  10,   5, -30 },
        { -30,   0,  15,  20,  20,  15,   0, -30 },
        { -30,   5,  15,  20,  20,  15,   5, -30 },
        { -30,   0,  10,  15,  15,  10,   0, -30 },
        { -40, -20,   0,   0,   0,   0, -20, -40 },
        { -50, -40, -30, -30, -30, -30, -40, -50 }
    };
                int[,] bishopTable = {
        { -20, -10, -10, -10, -10, -10, -10, -20 },
        { -10,   5,   0,   0,   0,   0,   5, -10 },
        { -10,  10,  10,  10,  10,  10,  10, -10 },
        { -10,   0,  10,  10,  10,  10,   0, -10 },
        { -10,   5,   5,  10,  10,   5,   5, -10 },
        { -10,   0,   5,  10,  10,   5,   0, -10 },
        { -10,   0,   0,   0,   0,   0,   0, -10 },
        { -20, -10, -10, -10, -10, -10, -10, -20 }
    };

                int[,] rookTable = {
        {  0,  0,  0,  5,  5,  0,  0,  0 },
        { -5, 10, 10, 10, 10, 10, 10, -5 },
        { -5,  0,  5,  5,  5,  5,  0, -5 },
        { -5,  0,  0,  5,  5,  0,  0, -5 },
        { -5,  0,  0,  5,  5,  0,  0, -5 },
        { -5,  0,  0,  5,  5,  0,  0, -5 },
        { -5,  0,  0,  5,  5,  0,  0, -5 },
        {  0,  0,  0,  5,  5,  0,  0,  0 }
    };

                int[,] queenTable = {
        { -20, -10, -10, -5, -5, -10, -10, -20 },
        { -10,   0,   0,  0,  0,   0,   0, -10 },
        { -10,   0,   5,  5,  5,   5,   0, -10 },
        {  -5,   0,   5,  5,  5,   5,   0,  -5 },
        {   0,   0,   5,  5,  5,   5,   0,  -5 },
        { -10,   5,   5,  5,  5,   5,   0, -10 },
        { -10,   0,   5,  0,  0,   0,   0, -10 },
        { -20, -10, -10, -5, -5, -10, -10, -20 }
    };

                int[,] kingTableMiddleGame = {
        { -30, -40, -40, -50, -50, -40, -40, -30 },
        { -30, -40, -40, -50, -50, -40, -40, -30 },
        { -30, -40, -40, -50, -50, -40, -40, -30 },
        { -30, -40, -40, -50, -50, -40, -40, -30 },
        { -20, -30, -30, -40, -40, -30, -30, -20 },
        { -10, -20, -20, -20, -20, -20, -20, -10 },
        {  20,  20,   0,   0,   0,   0,  20,  20 },
        {  20,  30,  10,   0,   0,  10,  30,  20 }
    };

                // Track king positions
                int whiteKingRow = -1, whiteKingCol = -1;
                int blackKingRow = -1, blackKingCol = -1;

                for (int row = 0; row < 8; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        Piece piece = board[row, col];
                        if (piece == null) continue;

                        int pieceValue = pieceValues[piece.GetType().Name];
                        int positionalScore = 0;

                        // Apply positional scoring
                        if (piece is Pawn) positionalScore = pawnTable[row, col];
                        else if (piece is Knight) positionalScore = knightTable[row, col];

                        int pieceScore = piece.Color == "White" ? pieceValue + positionalScore : -(pieceValue + positionalScore);
                        evaluation += pieceScore;

                        // Save king positions
                        if (piece is King)
                        {
                            if (piece.Color == "White") { whiteKingRow = row; whiteKingCol = col; }
                            else { blackKingRow = row; blackKingCol = col; }
                        }
                    }
                }

                int pawnShieldBonus = 15;
                int castlingBonus = 30;
                int kingExposurePenalty = 25;

                // Threat-Based Evaluation Weights
                int hangingPiecePenalty = -50;
                int kingAttackPenalty = -100;
                int defendedPieceBonus = 20;

                // Evaluate King Safety
                evaluation += EvaluateKingSafety(board, whiteKingRow, whiteKingCol, "White", pawnShieldBonus, castlingBonus, kingExposurePenalty);
                evaluation -= EvaluateKingSafety(board, blackKingRow, blackKingCol, "Black", pawnShieldBonus, castlingBonus, kingExposurePenalty);

                // Evaluate Threats
                evaluation += EvaluateThreats(board, "White", hangingPiecePenalty, kingAttackPenalty, defendedPieceBonus);
                evaluation -= EvaluateThreats(board, "Black", hangingPiecePenalty, kingAttackPenalty, defendedPieceBonus);

                return evaluation;
            }
            private List<((int, int, int, int), int)> FindCaptureMoves(Piece[,] board, string botColor, Dictionary<string, int> pieceValues)
            {
                List<((int, int, int, int), int)> captureMoves = new List<((int, int, int, int), int)>();
                string opponentColor = (botColor == "Black") ? "White" : "Black";

                for (int row = 0; row < 8; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        Piece piece = board[row, col];

                        if (piece != null && piece.Color == botColor)
                        {
                            // Check all possible capture moves
                            for (int targetRow = 0; targetRow < 8; targetRow++)
                            {
                                for (int targetCol = 0; targetCol < 8; targetCol++)
                                {
                                    Piece targetPiece = board[targetRow, targetCol];

                                    // Check if it captures an opponent piece
                                    if (targetPiece != null && targetPiece.Color == opponentColor &&
                                        piece.IsMoveLegal(row, col, targetRow, targetCol, board))
                                    {
                                        // Use dictionary to get the piece value
                                        int captureValue = pieceValues[targetPiece.GetType().Name];

                                        // Add the move along with its value
                                        captureMoves.Add(((row, col, targetRow, targetCol), captureValue));
                                    }
                                }
                            }
                        }
                    }
                }

                // Sort by value of captured piece
                captureMoves.Sort((a, b) => b.Item2.CompareTo(a.Item2));

                return captureMoves;
            }
            //King Safety Evaluation
            private int EvaluateKingSafety(Piece[,] board, int kingRow, int kingCol, string color, int pawnShieldBonus, int castlingBonus, int kingExposurePenalty)
            {
                if (kingRow == -1 || kingCol == -1) return 0;

                int score = 0;

                // Pawn Shield in front of the King
                int direction = (color == "White") ? -1 : 1;
                for (int offset = -1; offset <= 1; offset++)
                {
                    int shieldRow = kingRow + direction;
                    int shieldCol = kingCol + offset;

                    if (shieldRow >= 0 && shieldRow < 8 && shieldCol >= 0 && shieldCol < 8)
                    {
                        Piece piece = board[shieldRow, shieldCol];
                        if (piece is Pawn && piece.Color == color)
                            score += pawnShieldBonus;
                    }
                }

                // Check if King has castled
                if ((color == "White" && kingRow == 7 && (kingCol == 2 || kingCol == 6)) ||
                    (color == "Black" && kingRow == 0 && (kingCol == 2 || kingCol == 6)))
                {
                    score += castlingBonus;
                }

                // Penalise exposed King (few defenders)
                List<(int, int)> attackers = GetAttackers(board, kingRow, kingCol, color == "White" ? "Black" : "White");
                if (attackers.Count > 0)
                {
                    score -= kingExposurePenalty;
                }

                return score;
            }

            private int EvaluateThreats(Piece[,] board, string color, int hangingPiecePenalty, int kingAttackPenalty, int defendedPieceBonus)
            {
                int score = 0;

                for (int row = 0; row < 8; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        Piece piece = board[row, col];
                        if (piece == null || piece.Color != color) continue;

                        List<(int, int)> attackers = GetAttackers(board, row, col, color == "White" ? "Black" : "White");
                        List<(int, int)> defenders = GetAttackers(board, row, col, color);
                        //penalities and bonuses based off posiion
                        if (attackers.Count > 0 && (defenders.Count == 0 || PieceValue(board[attackers[0].Item1, attackers[0].Item2]) < PieceValue(piece)))
                        {
                            score += hangingPiecePenalty; 
                        }
                        if (piece is King && attackers.Count > 0)
                        {
                            score += kingAttackPenalty;
                        }
                        if (defenders.Count > 0)
                        {
                            score += defendedPieceBonus;
                        }
                    }
                }
                return score;
            }

            private List<(int, int)> GetAttackers(Piece[,] board, int row, int col, string attackerColor)
            {
                List<(int, int)> attackers = new();

                for (int r = 0; r < 8; r++)
                {
                    for (int c = 0; c < 8; c++)
                    {
                        Piece piece = board[r, c];
                        if (piece != null && piece.Color == attackerColor && piece.IsMoveLegal(r, c, row, col, board))
                        {
                            attackers.Add((r, c));
                        }
                    }
                }
                return attackers;
            }

            private int PieceValue(Piece piece)
            {
                if (piece == null) return 0;
                Dictionary<string, int> values = new()
    {
        { "Pawn", 100 }, { "Knight", 320 }, { "Bishop", 330 },
        { "Rook", 500 }, { "Queen", 900 }, { "King", 20000 }
    };
                return values.ContainsKey(piece.GetType().Name) ? values[piece.GetType().Name] : 0;
            }
            public List<(int, int, int, int)> GetAllLegalMoves(Piece[,] board, string color)
            {
                return BotUtils.GetAllLegalMoves(board, "Black");
            }
            private int Minimax(Piece[,] board, int depth, int alpha, int beta, bool isMaximizing)
            {
                if (depth == 0)
                {
                    return EvaluateBoard(board);

                }
                List<(int, int, int, int)> legalMoves = GetAllLegalMoves(board, "Black");

                if (legalMoves.Count == 0)
                {
                    return isMaximizing ? int.MinValue : int.MaxValue; 
                }
                legalMoves = legalMoves.OrderByDescending(move => EvaluateMovePriority(board, move)).ToList();

                if (isMaximizing) // Black (AI)
                {
                    int maxEval = int.MinValue;
                    foreach (var move in legalMoves)
                    {
                        Piece[,] newBoard = SimulateMove(board, move.Item1, move.Item2, move.Item3, move.Item4); //implementation of Alpha-Beta Pruning and Minimax algorithm
                        int eval = Minimax(newBoard, depth - 1, alpha, beta, false);
                        maxEval = Math.Max(maxEval, eval);
                        alpha = Math.Max(alpha, eval);

                        if (beta <= alpha)
                            break; // Prune
                    }
                    return maxEval;
                }
                else // White (Opponent)
                {
                    int minEval = int.MaxValue;
                    foreach (var move in legalMoves)
                    {
                        Piece[,] newBoard = SimulateMove(board, move.Item1, move.Item2, move.Item3, move.Item4);
                        int eval = Minimax(newBoard, depth - 1, alpha, beta, true);
                        minEval = Math.Min(minEval, eval);
                        beta = Math.Min(beta, eval);

                        if (beta <= alpha)
                            break; // Prune
                    }
                    return minEval;
                }
            }
            private int EvaluateMovePriority(Piece[,] board, (int, int, int, int) move)
            {
                int startRow = move.Item1, startCol = move.Item2;
                int endRow = move.Item3, endCol = move.Item4;

                Piece movingPiece = board[startRow, startCol];
                Piece targetPiece = board[endRow, endCol];

                int priority = 0;

                // Capturing a piece is high priority
                if (targetPiece != null)
                {
                    Dictionary<string, int> pieceValues = new()
        {
            { "Pawn", 100 }, { "Knight", 320 }, { "Bishop", 330 },
            { "Rook", 500 }, { "Queen", 900 }, { "King", 20000 }
        };

                    priority += pieceValues[targetPiece.GetType().Name]; // Higher value captures are prioritised
                }

                // Moving into an attack position is medium priority
                if (IsKingInCheck(board, move))
                {
                    priority += 500; // Give extra weight to checks
                }

                return priority;
            }
            private bool IsKingInCheck(Piece[,] board, (int, int, int, int) move)
            {
                Piece[,] testBoard = SimulateMove(board, move.Item1, move.Item2, move.Item3, move.Item4);
    
                 // Find the king's position
                  int kingRow = -1, kingCol = -1;
                  for (int row = 0; row < 8; row++)
                  {
                    for (int col = 0; col < 8; col++)
                    {
                        if (testBoard[row, col] is King && testBoard[row, col].Color == "White") // Checking opponent's king
                        {
                            kingRow = row;
                            kingCol = col;
                            break;
                        }
                    }
                  }

                // Check if any piece can attack the king
                for (int row = 0; row < 8; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        Piece piece = testBoard[row, col];
                        if (piece != null && piece.Color == "Black") // AI's pieces
                        {
                            if (piece.IsMoveLegal(row, col, kingRow, kingCol, testBoard))
                            {
                                return true; // King is under attack
                            }
                        }
                    }
                } 
                    return false;
            }
            public Piece[,] SimulateMove(Piece[,] board, int startRow, int startCol, int endRow, int endCol)
            {
                Piece[,] newBoard = new Piece[8, 8];

                // Copy the board state
                for (int row = 0; row < 8; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        newBoard[row, col] = board[row, col] != null ? board[row, col].Clone() : null;
                    }
                }

                Piece movingPiece = newBoard[startRow, startCol];

                if (movingPiece is King king && Math.Abs(startCol - endCol) == 2)
                {
                    // Castling logic
                    int rookCol = (endCol > startCol) ? 7 : 0;  // Rook column
                    int newRookCol = (endCol > startCol) ? endCol - 1 : endCol + 1;  // Rook destination

                    // Move the King
                    newBoard[endRow, endCol] = movingPiece;
                    newBoard[startRow, startCol] = null;

                    // Move the Rook
                    newBoard[endRow, newRookCol] = newBoard[endRow, rookCol];
                    newBoard[endRow, rookCol] = null;
                }
                else
                {
                    // Standard move
                    newBoard[endRow, endCol] = newBoard[startRow, startCol];
                    newBoard[startRow, startCol] = null;
                }

                // Set HasMoved flags for king and rook
                if (movingPiece is King)
                {
                    ((King)movingPiece).HasMoved = true;
                }
                else if (movingPiece is Rook)
                {
                    ((Rook)movingPiece).HasMoved = true;
                }

                return newBoard;
            }

            public void MakeAIMove(Piece[,] board)
            {
                List<(int, int, int, int)> legalMoves = GetAllLegalMoves(board, "Black");
                List<(int, int, int, int)> safeMoves = new List<(int, int, int, int)>();

                Dictionary<string, int> pieceValues = new()
    {
        { "Pawn", 100 }, { "Knight", 320 }, { "Bishop", 330 },
        { "Rook", 500 }, { "Queen", 900 }, { "King", 20000 }
    };

                // Filter out illegal moves that leave the king in check or capture protected pieces
                foreach (var move in legalMoves)
                {
                    Piece[,] simulatedBoard = SimulateMove(CloneBoard(board), move.Item1, move.Item2, move.Item3, move.Item4);

                    // Skip move if the Black king would be in check
                    if (!IsKingInCheckAfterMove(board, "Black", move) && !IsCapturingProtectedPiece(board, move))
                    {
                        safeMoves.Add(move);
                    }
                }

                if (safeMoves.Count == 0)
                {
                    if (IsKingInCheck(board, "Black"))
                    {
                        MessageBox.Show("Checkmate! You win!");
                    }
                    else
                    {
                        MessageBox.Show("Stalemate! It's a draw.");
                    }
                    return;
                }

                // Prioritise valuable captures first
                var captureMoves = FindCaptureMoves(board, "Black", pieceValues);

                // Only add valid captures (ignore protected pieces)
                var validCaptures = captureMoves
                    .Where(capture => !IsCapturingProtectedPiece(board, capture.Item1))
                    .ToList();

                if (validCaptures.Count > 0)
                {
                    var bestCapture = validCaptures[0].Item1;

                    ExecuteMove(board, bestCapture);
                    mainWindow.OnMoveMade(board);
                    mainWindow.CurrentPlayer = "White";
                    mainWindow.CheckForGameEnd(board);  // Ensure the game ends after a king is captured
                    return;
                }

                // Fallback to Minimax if no valid captures are available
                int bestEval = int.MinValue;
                (int, int, int, int) bestMove = safeMoves[0];

                foreach (var move in safeMoves)
                {
                    Piece[,] newBoard = SimulateMove(CloneBoard(board), move.Item1, move.Item2, move.Item3, move.Item4);
                    int eval = Minimax(newBoard, 3, int.MinValue, int.MaxValue, false);

                    if (eval > bestEval)
                    {
                        bestEval = eval;
                        bestMove = move;
                    }
                }

                ExecuteMove(board, bestMove);
                mainWindow.OnMoveMade(board);
                mainWindow.CurrentPlayer = "White";
                mainWindow.CheckForGameEnd(board);  // Ensure game ends when a king is captured
            }
            public void ExecuteMove(Piece[,] board, (int, int, int, int) move)
            {
                (int startRow, int startCol, int endRow, int endCol) = move;

                // Check for king capture
                if (board[endRow, endCol] is King)
                {
                    string winner = board[endRow, endCol].Color == "White" ? "Black" : "White";
                    mainWindow.ShowGameOverPrompt($"{winner} wins by capturing the King!");
                    return;
                }

                // Move the piece
                board[endRow, endCol] = board[startRow, startCol];
                board[startRow, startCol] = null;

                // Handle castling
                if (board[endRow, endCol] is King king && Math.Abs(startCol - endCol) == 2)
                {
                    // Handle rook movement during castling
                    int rookStartCol = (endCol > startCol) ? 7 : 0;
                    int rookEndCol = (endCol > startCol) ? endCol - 1 : endCol + 1;

                    board[endRow, rookEndCol] = board[endRow, rookStartCol];
                    board[endRow, rookStartCol] = null;

                    king.HasMoved = true;
                    ((Rook)board[endRow, rookEndCol]).HasMoved = true;
                }
                else if (board[endRow, endCol] is King)
                {
                    ((King)board[endRow, endCol]).HasMoved = true;
                }
                else if (board[endRow, endCol] is Rook)
                {
                    ((Rook)board[endRow, endCol]).HasMoved = true;
                }

                // Check for standard game-ending conditions
                mainWindow.CheckForGameEnd(board);
            }
            private bool IsCapturingProtectedPiece(Piece[,] board, (int, int, int, int) move)
            {
                int targetRow = move.Item3;
                int targetCol = move.Item4;

                // Check if the piece being captured is protected
                string opponentColor = board[move.Item1, move.Item2].Color == "White" ? "Black" : "White";

                // Loop through all pieces to see if any protect the target square
                for (int row = 0; row < 8; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        Piece piece = board[row, col];

                        if (piece != null && piece.Color == opponentColor)
                        {
                            if (piece.IsMoveLegal(row, col, targetRow, targetCol, board))
                            {
                                return true;  // The target piece is protected
                            }
                        }
                    }
                }

                return false;  // The piece is not protected
            }
            private List<(int, int, int, int)> FindHangingPieceMoves(Piece[,] board, string botColor)
            {
                List<(int, int, int, int)> hangingMoves = new List<(int, int, int, int)>();
                string opponentColor = (botColor == "Black") ? "White" : "Black";

                // Loop through all bot pieces
                for (int row = 0; row < 8; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        Piece piece = board[row, col];

                        if (piece != null && piece.Color == botColor)
                        {
                            // Check all possible capture moves
                            for (int targetRow = 0; targetRow < 8; targetRow++)
                            {
                                for (int targetCol = 0; targetCol < 8; targetCol++)
                                {
                                    Piece targetPiece = board[targetRow, targetCol];

                                    // Check if the move is legal and captures an opponent piece
                                    if (targetPiece != null && targetPiece.Color == opponentColor &&
                                        piece.IsMoveLegal(row, col, targetRow, targetCol, board))
                                    {
                                        // Simulate the capture move
                                        Piece[,] simulatedBoard = SimulateMove(CloneBoard(board), row, col, targetRow, targetCol);

                                        // Ensure the capturing piece is not immediately recaptured
                                        if (!IsSquareAttacked(simulatedBoard, targetRow, targetCol, opponentColor))
                                        {
                                            hangingMoves.Add((row, col, targetRow, targetCol));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                return hangingMoves;
            }
            private bool IsSquareAttacked(Piece[,] board, int row, int col, string attackerColor)
            {
                for (int x = 0; x < 8; x++)
                {
                    for (int y = 0; y < 8; y++)
                    {
                        Piece piece = board[x, y];
                        if (piece != null && piece.Color == attackerColor)
                        {
                            if (piece.IsMoveLegal(x, y, row, col, board))
                            {
                                return true;  // Square is under attack
                            }
                        }
                    }
                }
                return false;
            }
            public bool IsKingInCheck(Piece[,] board, string currentPlayer)
            {
                // Locate the king
                int kingX = -1, kingY = -1;

                for (int x = 0; x < 8; x++)
                {
                    for (int y = 0; y < 8; y++)
                    {
                        var piece = board[x, y]; 

                        if (piece is King && piece.Color == currentPlayer)
                        {
                            kingX = x;
                            kingY = y;
                            break;
                        }
                    }
                    if (kingX != -1) break;  // King found, exit outer loop
                }

                if (kingX == -1 || kingY == -1)
                    return false;  // No king found (should not happen)

                // Check if the king is under attack
                string opponent = currentPlayer == "White" ? "Black" : "White";

                for (int x = 0; x < 8; x++)
                {
                    for (int y = 0; y < 8; y++)
                    {
                        var piece = board[x, y]; 

                        if (piece != null && piece.Color == opponent && piece.IsMoveLegal(x, y, kingX, kingY, board))
                        {
                            return true;  // King is in check
                        }
                    }
                }

                return false;  // King is safe
            }
            public bool IsKingInCheckAfterMove(Piece[,] board, string currentPlayer, (int, int, int, int) move)
            {
                // Clone the board and simulate the move
                Piece[,] tempBoard = (Piece[,])board.Clone();

                // Perform the move
                tempBoard[move.Item3, move.Item4] = tempBoard[move.Item1, move.Item2];
                tempBoard[move.Item1, move.Item2] = null;

                // Locate the king
                int kingX = -1, kingY = -1;

                for (int x = 0; x < 8; x++)
                {
                    for (int y = 0; y < 8; y++)
                    {
                        var piece = tempBoard[x, y];
                        if (piece is King && piece.Color == currentPlayer)
                        {
                            kingX = x;
                            kingY = y;
                            break;
                        }
                    }
                    if (kingX != -1) break;
                }

                if (kingX == -1 || kingY == -1)
                    return false;  // No king found (should not happen)

                // Check if the king is under attack
                string opponent = currentPlayer == "White" ? "Black" : "White";

                for (int x = 0; x < 8; x++)
                {
                    for (int y = 0; y < 8; y++)
                    {
                        var piece = tempBoard[x, y];
                        if (piece != null && piece.Color == opponent && piece.IsMoveLegal(x, y, kingX, kingY, tempBoard))
                        {
                            return true;  // King is in check
                        }
                    }
                }

                return false;  // King is safe
            }
            private Piece[,] CloneBoard(Piece[,] board)
            {
                Piece[,] newBoard = new Piece[8, 8]; // Create a new 8x8 board

                for (int row = 0; row < 8; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        if (board[row, col] != null)
                        {
                            newBoard[row, col] = board[row, col].Clone(); 
                        }
                        else
                        {
                            newBoard[row, col] = null;
                        }
                    }
                }
                return newBoard;
            }
        }
        //BotUtils are for methods used by both bots, that are identical to each other
        public static class BotUtils
        {
            public static List<(int, int, int, int)> GetAllLegalMoves(Piece[,] board, string color)
            {
                List<(int, int, int, int)> legalMoves = new();  // List of all legal moves

                for (int row = 0; row < 8; row++)
                {
                    for (int col = 0; col < 8; col++)
                    {
                        Piece piece = board[row, col];

                        if (piece != null && piece.Color == color)  // Only consider the bot's color
                        {
                            for (int targetRow = 0; targetRow < 8; targetRow++)
                            {
                                for (int targetCol = 0; targetCol < 8; targetCol++)
                                {
                                    if (piece.IsMoveLegal(row, col, targetRow, targetCol, board))
                                    {
                                        Piece targetPiece = board[targetRow, targetCol];

                                        // Avoid capturing friendly pieces
                                        if (targetPiece == null || targetPiece.Color != color)
                                        {
                                            legalMoves.Add((row, col, targetRow, targetCol));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                return legalMoves;
            }
        }
    }
} 
    

        
 